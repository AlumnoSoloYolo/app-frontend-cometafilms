import { RuntimePipe } from './runtime.pipe';

describe('RuntimePipe', () => {
  it('create an instance', () => {
    const pipe = new RuntimePipe();
    expect(pipe).toBeTruthy();
  });
});
