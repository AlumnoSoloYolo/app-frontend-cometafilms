import { VotoColorPipe } from './voto-color.pipe';

describe('VotoColorPipe', () => {
  it('create an instance', () => {
    const pipe = new VotoColorPipe();
    expect(pipe).toBeTruthy();
  });
});
