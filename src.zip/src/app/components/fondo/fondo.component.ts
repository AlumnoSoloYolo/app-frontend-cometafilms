import { Component } from '@angular/core';

@Component({
  selector: 'app-fondo',
  standalone: true,
  imports: [],
  templateUrl: './fondo.component.html',
  styleUrl: './fondo.component.css'
})
export class FondoComponent {

}
