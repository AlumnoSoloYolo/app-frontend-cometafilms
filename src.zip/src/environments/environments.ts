export const environment = {
    production: false,
    tmdbToken: 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwMTc3MjUyNzIzYjdhMDhmNDdmNTcxNmVlNjcwOThkNSIsIm5iZiI6MTczODU4NDgwNy45Miwic3ViIjoiNjdhMGIyZTcwNGNiNmY0MWI5Y2I4Y2NjIiwic2NvcGVzIjpbImFwaV9yZWFkIl0sInZlcnNpb24iOjF9.4_LnrBtw5KaMsNXw8uGjxBSsxFPzW-63-v9srnr5iZg',
    apiUrl: 'http://localhost:3000',
    movieApiUrl: 'https://api.themoviedb.org/3'
};